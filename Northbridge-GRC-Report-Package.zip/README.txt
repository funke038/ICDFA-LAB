NORTHBRIDGE GRC RISK TREATMENT LAB - EVIDENCE README
====================================================
Fictional organisation, dummy data only. Two isolated VMware VMs (host-only network).
  Ubuntu server : 172.16.140.128 (ens33)   - files under ubuntu/   (times UTC+01:00)
  Kali client   : 172.16.140.129 (eth0)    - files in top folder   (times UTC-05:00)
  Blocked test  : 172.16.140.50 (temporary second address on Kali eth0)
The report converts all times to UTC. No passwords, keys or disk images are included.

STEP -> EVIDENCE
----------------
Steps 1-3  Build
  kali-ip.txt, ubuntu/ubuntu-ip.txt          VM addresses
  ubuntu/grc-lab                             final nginx site config
  ubuntu/grc-legacy.service                  legacy systemd unit
  ubuntu/apache-disabled.txt                 pre-installed Apache disabled (deviation)

Step 4  Baseline
  baseline-time.txt, baseline-ports.txt      first baseline (8080 already retired - see report s.2)
  baseline-web.txt, baseline-listing.txt     directory listings HTTP 200
  baseline-file.txt                          dummy record HTTP 200
  baseline-legacy.txt                        8080 refused (first baseline)
  baseline-recheck-time.txt,
  baseline-ports-recheck.txt,
  baseline-legacy-recheck.txt                recaptured baseline: 8080 open, HTTP 200
  ubuntu/baseline-ufw.txt                    UFW inactive
  ubuntu/baseline-ss.txt                     listening services

Step 6  Avoidance
  ubuntu/avoid-time.txt, avoid-active.txt, avoid-ss.txt
  ubuntu/rollback-test.txt                   rollback active -> inactive
  avoidance-ports.txt                        8080 closed, 80 open
  avoidance-legacy.txt                       8080 connection refused
  avoidance-web.txt                          portal HTTP 200
  ubuntu/final-legacy-state.txt              disabled

Step 7  Archive hardening
  hardening-tests.txt                        200 / 403 / 403 / 403
  ubuntu/nginx-access.txt                    200 before, 403 after

Step 8  Firewall
  ubuntu/ufw-rules.txt                       first rule set
  firewall-tests.txt                         FIRST TEST FAILED (blocked IP got 200)
  ubuntu/ufw-rules-at-failure.txt            root cause: "Apache Full ALLOW Anywhere"
  ubuntu/ufw-rules-fixed.txt                 after reset: single allow rule
  firewall-tests-retest.txt                  RETEST PASSED (blocked IP timed out)
  ubuntu/ufw-rules-final.txt                 final rule set

Step 9  Log correlation
  ubuntu/nginx-access.txt                    shows 172.16.140.50 served (failure)
  ubuntu/nginx-access-retest.txt             retest web log
  ubuntu/ufw-block.txt                       EMPTY - filter used wrong example IP (kept unedited)
  ubuntu/ufw-block-retest.txt                UFW BLOCK entries for retest

Step 10  Backup and recovery
  ubuntu/portal-before.sha256                original hash
  ubuntu/recovery-start.txt, recovery-end.txt
  ubuntu/recovery-hash.txt                   index.html: OK
  ubuntu/recovery-time.txt                   187 seconds
  recovery-failed.txt                        portal not served (403)
  recovery-restored.txt                      portal restored (200)

Steps 11-12  Decisions and costs
  calculation-workbook.xlsx                  costs, ALE (assumptions), risk scores, recovery time
  Northbridge-GRC-Risk-Treatment-Report.pdf  full report incl. management summary

screenshots/                                 console screenshots (add your own)
